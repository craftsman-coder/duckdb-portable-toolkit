"""Tests for regression models."""
